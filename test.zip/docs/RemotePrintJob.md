# RemotePrintJob

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | Option<**String**> |  | [optional]
**version** | Option<**String**> |  | [optional]
**created_date** | Option<**i32**> |  | [optional]
**document_id** | **String** |  | 
**last_modified_date** | Option<**i32**> |  | [optional]
**print_status** | **String** |  | 
**printer_name** | **String** |  | 
**quantity** | **i32** |  | 
**user_id** | Option<**String**> |  | [optional]
**weclapp_os_hardware_id** | Option<**String**> |  | [optional]
**weclapp_os_id** | **String** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


