# ProductionOrderFastProductionBookingPostRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**quantity** | [**crate::models::custom_attribute_definition::AttributeType**](decimal.md) |  | 
**production_order_number** | **String** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


