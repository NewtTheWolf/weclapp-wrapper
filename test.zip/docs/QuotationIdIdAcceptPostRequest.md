# QuotationIdIdAcceptPostRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accept_quotation_items** | Option<[**Vec<crate::models::AcceptQuotationItem>**](acceptQuotationItem.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


