# FulfillmentProvider

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | Option<**String**> |  | [optional]
**version** | Option<**String**> |  | [optional]
**created_date** | Option<**i32**> |  | [optional]
**fulfillment_provider_type** | **String** |  | 
**last_modified_date** | Option<**i32**> |  | [optional]
**name** | **String** |  | 
**warehouse_id** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


