# TaxConfigureSalesTaxesPostRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**country_code** | **String** |  | 
**persons_third_country_free_tax** | **bool** |  | 
**tax_eu_persons_recipient_country** | **bool** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


