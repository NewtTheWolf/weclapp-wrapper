# PurchaseOrderRequestIdIdCreateBlanketPurchaseOrderPostRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offer_item_id** | **i32** |  | 
**ordered_quantity** | [**crate::models::custom_attribute_definition::AttributeType**](decimal.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


