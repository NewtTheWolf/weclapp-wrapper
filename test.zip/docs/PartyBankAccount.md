# PartyBankAccount

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | Option<**String**> |  | [optional]
**version** | Option<**String**> |  | [optional]
**account_holder** | Option<**String**> |  | [optional]
**account_number** | **String** |  | 
**bank_code** | **String** |  | 
**created_date** | Option<**i32**> |  | [optional]
**credit_institute** | Option<**String**> |  | [optional]
**last_modified_date** | Option<**i32**> |  | [optional]
**party_id** | **String** |  | 
**primary** | Option<**bool**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


