# RecurringEvent

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | Option<**String**> |  | [optional]
**version** | Option<**String**> |  | [optional]
**created_date** | Option<**i32**> |  | [optional]
**ends_on** | Option<**i32**> |  | [optional]
**event_interval** | Option<**i32**> |  | [optional]
**event_occurrence_count** | Option<**i32**> |  | [optional]
**event_type** | Option<**String**> |  | [optional]
**last_modified_date** | Option<**i32**> |  | [optional]
**repeat_on** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


