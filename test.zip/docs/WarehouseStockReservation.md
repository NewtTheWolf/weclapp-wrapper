# WarehouseStockReservation

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**production_order_item_id** | Option<**String**> |  | [optional]
**reserved_quantity** | [**crate::models::custom_attribute_definition::AttributeType**](decimal.md) |  | 
**shipment_item_id** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


