# ContractAdditionalAddress

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | Option<**String**> |  | [optional]
**version** | Option<**String**> |  | [optional]
**address** | Option<[**crate::models::RecordAddress**](recordAddress.md)> |  | [optional]
**created_date** | Option<**i32**> |  | [optional]
**description** | Option<**String**> |  | [optional]
**last_modified_date** | Option<**i32**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


