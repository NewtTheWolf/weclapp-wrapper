# VariantArticleVariantWithoutReference

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | Option<**String**> |  | [optional]
**version** | Option<**String**> |  | [optional]
**article_id** | Option<**String**> |  | [optional]
**article_number** | Option<**String**> |  | [optional]
**attribute_options** | Option<[**Vec<crate::models::OnlyId>**](onlyId.md)> |  | [optional]
**created_date** | Option<**i32**> |  | [optional]
**last_modified_date** | Option<**i32**> |  | [optional]
**position_number** | Option<**i32**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


