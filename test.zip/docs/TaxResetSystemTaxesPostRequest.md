# TaxResetSystemTaxesPostRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**country_code** | **String** |  | 
**persons_third_country_free_tax** | **bool** |  | 
**init_all_stores** | **bool** |  | 
**tax_recipient_country** | **bool** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


