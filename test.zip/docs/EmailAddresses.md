# EmailAddresses

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bcc_addresses** | Option<**String**> |  | [optional]
**cc_addresses** | Option<**String**> |  | [optional]
**to_addresses** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


