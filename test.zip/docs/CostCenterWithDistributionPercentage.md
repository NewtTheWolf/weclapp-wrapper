# CostCenterWithDistributionPercentage

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | Option<**String**> |  | [optional]
**version** | Option<**String**> |  | [optional]
**cost_center_id** | **String** |  | 
**cost_center_number** | Option<**String**> |  | [optional]
**created_date** | Option<**i32**> |  | [optional]
**distribution_percentage** | [**crate::models::custom_attribute_definition::AttributeType**](decimal.md) |  | 
**last_modified_date** | Option<**i32**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


