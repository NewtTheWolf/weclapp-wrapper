# PartyEmailAddresses

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | Option<**String**> |  | [optional]
**version** | Option<**String**> |  | [optional]
**bcc_addresses** | Option<**String**> |  | [optional]
**cc_addresses** | Option<**String**> |  | [optional]
**created_date** | Option<**i32**> |  | [optional]
**last_modified_date** | Option<**i32**> |  | [optional]
**to_addresses** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


