# DemoTestSystemInfo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**create_possible** | Option<**bool**> |  | [optional]
**creation_in_progress** | Option<**bool**> |  | [optional]
**demo_instance_url** | Option<**String**> |  | [optional]
**main_instance_url** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


