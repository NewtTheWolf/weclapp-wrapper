# ArticleCalculationPrice

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | Option<**String**> |  | [optional]
**version** | Option<**String**> |  | [optional]
**article_calculation_price_type** | **String** |  | 
**created_date** | Option<**i32**> |  | [optional]
**end_date** | Option<**i32**> |  | [optional]
**last_modified_date** | Option<**i32**> |  | [optional]
**position_number** | Option<**i32**> |  | [optional]
**price** | [**crate::models::custom_attribute_definition::AttributeType**](decimal.md) |  | 
**sales_channel** | Option<**String**> |  | [optional]
**start_date** | Option<**i32**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


