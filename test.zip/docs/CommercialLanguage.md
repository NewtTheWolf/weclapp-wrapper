# CommercialLanguage

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | Option<**String**> |  | [optional]
**version** | Option<**String**> |  | [optional]
**country_code** | Option<**String**> |  | [optional]
**created_date** | Option<**i32**> |  | [optional]
**language_code** | **String** |  | 
**last_modified_date** | Option<**i32**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


