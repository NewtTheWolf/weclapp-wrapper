# AttendanceCurrentAttendanceGet200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**result** | Option<[**crate::models::Attendance**](attendance.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


