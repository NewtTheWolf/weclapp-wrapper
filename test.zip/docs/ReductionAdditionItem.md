# ReductionAdditionItem

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**position** | Option<**i32**> |  | [optional]
**source** | Option<**String**> |  | [optional]
**r#type** | Option<**String**> |  | [optional]
**value** | Option<[**crate::models::custom_attribute_definition::AttributeType**](decimal.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


