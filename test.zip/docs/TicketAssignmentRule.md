# TicketAssignmentRule

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | Option<**String**> |  | [optional]
**version** | Option<**String**> |  | [optional]
**assignee_user_id** | Option<**String**> |  | [optional]
**commercial_language** | Option<**String**> |  | [optional]
**created_date** | Option<**i32**> |  | [optional]
**distribution_channel** | Option<**String**> |  | [optional]
**last_modified_date** | Option<**i32**> |  | [optional]
**party_id** | Option<**String**> |  | [optional]
**responsible_user_id** | Option<**String**> |  | [optional]
**target_status_id** | Option<**String**> |  | [optional]
**ticket_assignee_type** | Option<**String**> |  | [optional]
**ticket_category_id** | Option<**String**> |  | [optional]
**ticket_channel_id** | Option<**String**> |  | [optional]
**ticket_priority_id** | Option<**String**> |  | [optional]
**ticket_type_id** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


