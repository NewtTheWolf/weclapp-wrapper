# ValidationError

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**allowed** | Option<**Vec<String>**> |  | [optional]
**detail** | Option<**String**> |  | [optional]
**instance** | Option<**String**> |  | [optional]
**location** | Option<**String**> |  | [optional]
**title** | Option<**String**> |  | [optional]
**r#type** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


