# PurchaseOrderRequestOfferItemInformation

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offer_item_id** | Option<**i32**> |  | [optional]
**quantity** | Option<[**crate::models::custom_attribute_definition::AttributeType**](decimal.md)> |  | [optional]
**sales_order_item_id** | Option<**i32**> |  | [optional]
**update_information** | Option<**bool**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


