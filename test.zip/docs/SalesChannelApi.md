# \SalesChannelApi

All URIs are relative to *https://www.weclapp.com/webapp/api/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**sales_channel_active_sales_channels_get**](SalesChannelApi.md#sales_channel_active_sales_channels_get) | **GET** /salesChannel/activeSalesChannels | 



## sales_channel_active_sales_channels_get

> crate::models::SalesChannelActiveSalesChannelsGet200Response sales_channel_active_sales_channels_get()


### Parameters

This endpoint does not need any parameter.

### Return type

[**crate::models::SalesChannelActiveSalesChannelsGet200Response**](_salesChannel_activeSalesChannels_get_200_response.md)

### Authorization

[API token](../README.md#API token)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

