# ShippingCarrier

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | Option<**String**> |  | [optional]
**version** | Option<**String**> |  | [optional]
**active** | Option<**bool**> |  | [optional]
**created_date** | Option<**i32**> |  | [optional]
**internal_shipping_carrier** | Option<**String**> |  | [optional]
**last_modified_date** | Option<**i32**> |  | [optional]
**name** | **String** |  | 
**position_number** | Option<**i32**> |  | [optional]
**tracking_url** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


