# BlanketPurchaseOrderIdIdGenerateReleasesPostRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**first_scheduled_delivery_date** | **i32** |  | 
**repeat_interval** | **i32** |  | 
**repeat_type** | **String** |  | 
**fix_released_quantity** | **bool** |  | 
**released_quantity** | Option<[**crate::models::custom_attribute_definition::AttributeType**](decimal.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


