# SalesBillOfMaterialArticleItem

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | Option<**String**> |  | [optional]
**version** | Option<**String**> |  | [optional]
**article_id** | **String** |  | 
**article_number** | Option<**String**> |  | [optional]
**created_date** | Option<**i32**> |  | [optional]
**last_modified_date** | Option<**i32**> |  | [optional]
**position_number** | Option<**i32**> |  | [optional]
**quantity** | [**crate::models::custom_attribute_definition::AttributeType**](decimal.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


