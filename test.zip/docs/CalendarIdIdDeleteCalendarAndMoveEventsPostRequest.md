# CalendarIdIdDeleteCalendarAndMoveEventsPostRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**replacement_calendar_id** | **String** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


