# RecordAddress

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**city** | Option<**String**> |  | [optional]
**company** | Option<**String**> |  | [optional]
**company2** | Option<**String**> |  | [optional]
**country_code** | Option<**String**> |  | [optional]
**first_name** | Option<**String**> |  | [optional]
**global_location_number** | Option<**String**> |  | [optional]
**last_name** | Option<**String**> |  | [optional]
**middle_name** | Option<**String**> |  | [optional]
**phone_number** | Option<**String**> |  | [optional]
**post_office_box_city** | Option<**String**> |  | [optional]
**post_office_box_number** | Option<**String**> |  | [optional]
**post_office_box_zip_code** | Option<**String**> |  | [optional]
**salutation** | Option<**String**> |  | [optional]
**state** | Option<**String**> |  | [optional]
**street1** | Option<**String**> |  | [optional]
**street2** | Option<**String**> |  | [optional]
**title** | Option<**String**> |  | [optional]
**title_id** | Option<**String**> |  | [optional]
**zipcode** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


