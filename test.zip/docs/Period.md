# Period

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | Option<**String**> |  | [optional]
**version** | Option<**String**> |  | [optional]
**created_date** | Option<**i32**> |  | [optional]
**financial_year_id** | **String** |  | 
**last_modified_date** | Option<**i32**> |  | [optional]
**name** | **String** |  | 
**open** | Option<**bool**> |  | [optional]
**period_number** | **i32** |  | 
**valid_from** | Option<**i32**> |  | [optional]
**valid_to** | Option<**i32**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


